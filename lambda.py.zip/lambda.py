import os

def lambda_handler(event, context):
    message = f'Hello {os.getenv("first_name")} {os.getenv("last_name")}! Keep being awesome!'
    print(message)
    return {
        'message' : message
    }